import { useState, useEffect } from 'react';

function useScroll() {
  const [isSticky, setIsSticky] = useState(true);
  const [offsets, setOffsets] = useState([0, 0, 0]); // Array for offsets
  const [isHidden, setIsHidden] = useState(false);
  const hideThreshold = 100;

  useEffect(() => {
    let isThrottled = false;

    const handleScroll = () => {
      if (!isThrottled) {
        requestAnimationFrame(() => {
          const stickyAnchor = document.getElementById('sticky-anchor');
          const lastContainer = document.getElementById('last-container');
          if (!stickyAnchor || !lastContainer) return;

          const stickyTop = stickyAnchor.getBoundingClientRect().top;
          const lastContainerBottom = lastContainer.getBoundingClientRect().bottom;

          setIsSticky(stickyTop <= 100);
          setIsHidden(lastContainerBottom < window.innerHeight + hideThreshold);
        });
        isThrottled = true;
      }
    };

    const handleResize = () => {
      setOffsets([
        calculateOffset('scrollspyHeading1'),
        calculateOffset('scrollspyHeading2'),
        calculateOffset('scrollspyHeading3'),
      ]);
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const calculateOffset = (id) => {
    const element = document.getElementById(id);
    return element ? element.getBoundingClientRect().top + window.scrollY : 0;
  };

  return { isSticky, offsets, isHidden };
}

export default useScroll;
